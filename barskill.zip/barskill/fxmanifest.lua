fx_version 'cerulean'
games { 'gta5' }
lua54 "yes"
author 'ANTUNES'
description 'Karma Developments RepairSkill Minigame'

ui_page 'RepairKit.html'

files {
  'RepairKit.html',
  'RepairKit.js',
  'RepairKit.css',
}

client_scripts{
  'client.lua',
}